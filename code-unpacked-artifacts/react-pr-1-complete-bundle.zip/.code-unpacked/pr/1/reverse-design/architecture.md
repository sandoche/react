# Compiler boundaries and review map

Document family: C4 architecture

## Purpose and constraints

**Observed**

The imported compiler optimizes components/hooks while validating selected Rules of React. Its documented goals favor predictable updates, neutral startup cost and debuggable high-level output. Perfect minimal recomputation, class components and the entire JavaScript language are explicit non-goals. Treat performance claims as design goals; this review did not benchmark applications.

Sources: [`compiler/docs/DESIGN_GOALS.md:5–55`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/docs/DESIGN_GOALS.md#L5-L55)

## Execution versus supporting lanes

**Observed**

The TypeScript Babel plugin is the transformation entry. ESLint and healthcheck reuse it with noEmit. snap and Sprout provide fixture/snapshot and execution comparison support. The playground consumes pipeline yields for inspection. The Rust tree is documented WIP/unused and should not appear as a required Babel runtime dependency.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Babel/BabelPlugin.ts:20–51`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Babel/BabelPlugin.ts#L20-L51) · [`compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts:36–56`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts#L36-L56) · [`compiler/packages/react-compiler-healthcheck/src/checks/reactCompiler.ts:19–65`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/react-compiler-healthcheck/src/checks/reactCompiler.ts#L19-L65) · [`compiler/packages/snap/src/runner.ts:71–113`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/runner.ts#L71-L113) · [`compiler/packages/snap/src/sprout/index.ts:31–63`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/sprout/index.ts#L31-L63) · [`compiler/apps/playground/components/Editor/EditorImpl.tsx:166–220`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/apps/playground/components/Editor/EditorImpl.tsx#L166-L220) · [`compiler/docs/DEVELOPMENT_GUIDE.md:5–28`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/docs/DEVELOPMENT_GUIDE.md#L5-L28)

## Suggested review order

**Proposed**

1. Establish source/selection, noEmit and error policy.
2. Check lowering, CFG/SSA and effect assumptions.
3. Check input validation and flag defaults.
4. Check scope grouping, hook flattening and conditional dependency safety.
5. Trace generated cache writes/loads into native and compatibility runtimes.
6. Follow diagnostics through ESLint/healthcheck and review representative fixture/evaluator pairs.
7. Review playground, Rust and packaging in separate supporting lanes.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:216–269`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L216-L269) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:140–195`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L140-L195) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:318–380`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L318-L380) · [`packages/react-reconciler/src/ReactFiberHooks.js:1119–1200`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/packages/react-reconciler/src/ReactFiberHooks.js#L1119-L1200) · [`compiler/docs/DEVELOPMENT_GUIDE.md:5–28`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/docs/DEVELOPMENT_GUIDE.md#L5-L28)

## Execution and supporting boundaries

Which modules transform code, consume diagnostics, and support development?

```mermaid
flowchart TD
 Source["JS / TS / Flow source"] --> Babel["Babel Program plugin"]
 Babel --> Core["TypeScript compiler pipeline"]
 Core --> AST["Memoized Babel AST"]
 AST --> Import["c from selected runtime module"]
 Import --> Native["React dispatcher memo cache"]
 ESLint["ESLint: noEmit diagnostics"] --> Babel
 Health["Healthcheck: noEmit events"] --> Babel
 Snap["snap fixtures"] --> Babel
 Snap --> Sprout["Original / compiled evaluator"]
 Playground["Playground"] --> Core
 Rust["Rust WIP: documented unused"]
```

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Babel/BabelPlugin.ts:20–51`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Babel/BabelPlugin.ts#L20-L51) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:216–269`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L216-L269) · [`compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts:36–56`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts#L36-L56) · [`compiler/packages/react-compiler-healthcheck/src/checks/reactCompiler.ts:19–65`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/react-compiler-healthcheck/src/checks/reactCompiler.ts#L19-L65) · [`compiler/packages/snap/src/runner-worker.ts:130–180`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/runner-worker.ts#L130-L180) · [`compiler/packages/snap/src/sprout/index.ts:31–63`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/sprout/index.ts#L31-L63) · [`compiler/apps/playground/components/Editor/EditorImpl.tsx:166–220`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/apps/playground/components/Editor/EditorImpl.tsx#L166-L220) · [`packages/react/compiler-runtime.js:1–10`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/packages/react/compiler-runtime.js#L1-L10) · [`compiler/docs/DEVELOPMENT_GUIDE.md:5–28`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/docs/DEVELOPMENT_GUIDE.md#L5-L28)

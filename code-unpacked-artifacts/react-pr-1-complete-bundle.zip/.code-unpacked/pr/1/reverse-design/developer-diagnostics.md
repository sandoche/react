# Diagnostics, readiness tooling and playground

Document family: Sequence diagrams

## Different consumers, shared core

**Observed**

ESLint fixes options to noEmit/infer/all_errors. It attempts Hermes parsing, then Babel for TypeScript, invokes the compiler plugin, and reports the chosen severity levels only when a real location exists. Healthcheck uses noEmit/infer/critical_errors and a logger that separates success, actionable InvalidReact/InvalidJS and other failures. Neither consumer executes an optimized application.

Sources: [`compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts:36–56`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts#L36-L56) · [`compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts:116–163`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts#L116-L163) · [`compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts:217–228`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts#L217-L228) · [`compiler/packages/react-compiler-healthcheck/src/checks/reactCompiler.ts:19–65`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/react-compiler-healthcheck/src/checks/reactCompiler.ts#L19-L65)

## End-to-end diagnostic review

**Proposed**

For a new rule, inspect pass severity/location, Program logging and threshold behavior, ESLint filtering/suppression handling and healthcheck categorization. A new error can be correct internally yet invisible or miscategorized to a developer. Proposed regression proof should traverse at least one actual consumer.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Validation/ValidateHooksUsage.ts:79–129`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Validation/ValidateHooksUsage.ts#L79-L129) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:94–129`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L94-L129) · [`compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts:116–163`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts#L116-L163) · [`compiler/packages/react-compiler-healthcheck/src/checks/reactCompiler.ts:19–65`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/react-compiler-healthcheck/src/checks/reactCompiler.ts#L19-L65)

## Playground boundary

**Observed**

The Editor parses top-level functions, calls the pipeline generator and gathers printed results. The shown compilation path limits accepted function forms differently from Program selection. Source text persists in localStorage/URL hash, not a demonstrated server project database. Use it for intermediate-pass inspection and reproduce behavior through Babel plus fixtures before treating it as rollout proof.

Sources: [`compiler/apps/playground/components/Editor/EditorImpl.tsx:45–95`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/apps/playground/components/Editor/EditorImpl.tsx#L45-L95) · [`compiler/apps/playground/components/Editor/EditorImpl.tsx:166–220`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/apps/playground/components/Editor/EditorImpl.tsx#L166-L220) · [`compiler/apps/playground/lib/stores/store.ts:18–66`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/apps/playground/lib/stores/store.ts#L18-L66) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:464–525`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L464-L525)

## Diagnostic consumers

How do the same compiler results become lint reports or healthcheck counts?

```mermaid
flowchart LR
 Rule["Compiler pass error"] --> Program["Program error handling"]
 Program --> Threshold["Panic threshold / throw"]
 Program --> Logger["Logger events"]
 Threshold --> Lint["ESLint severity + location filter"]
 Logger --> Health["Healthcheck success / actionable / other"]
```

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Validation/ValidateHooksUsage.ts:79–129`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Validation/ValidateHooksUsage.ts#L79-L129) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:94–129`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L94-L129) · [`compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts:36–56`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts#L36-L56) · [`compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts:116–163`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts#L116-L163) · [`compiler/packages/react-compiler-healthcheck/src/checks/reactCompiler.ts:19–65`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/react-compiler-healthcheck/src/checks/reactCompiler.ts#L19-L65)

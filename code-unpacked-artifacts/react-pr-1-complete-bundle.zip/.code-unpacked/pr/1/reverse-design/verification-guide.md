# Review evidence, test strategy and remaining gaps

Document family: Verification

## What the existing harness does

**Observed**

snap discovers fixtures and transforms them in workers or synchronously. The test compiler starts from all/all_errors and accepts pragma overrides. The worker validates expected-error cases, assembles golden output and invokes Sprout when evaluator code exists. Sprout compares result kind, value and ordered logs; sequential render inputs mount once and rerender with supplied props.

Sources: [`compiler/packages/snap/src/runner.ts:71–113`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/runner.ts#L71-L113) · [`compiler/packages/snap/src/compiler.ts:32–66`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/compiler.ts#L32-L66) · [`compiler/packages/snap/src/runner-worker.ts:130–180`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/runner-worker.ts#L130-L180) · [`compiler/packages/snap/src/sprout/index.ts:31–63`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/sprout/index.ts#L31-L63) · [`compiler/packages/snap/src/sprout/evaluator.ts:114–142`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/sprout/evaluator.ts#L114-L142)

## Representative invariant matrix

**Proposed**

| Review invariant | Suggested evidence case |
| --- | --- |
| Selection and gating | opt-out, infer/annotation/all, default export, pre-declaration use |
| CFG/SSA | join, loop back edge, nested closure assignment |
| Effects/aliases | store through alias, capture, mutation after readonly use |
| Hook safety | nested hook scope and use participation on cache hit |
| Dependencies | guarded null, optional path, early return, break/continue |
| Cache protocol | cold sentinel, hit/miss, escaping output, throw before stores |
| Runtime | fixed slot count, retry/interruption, standalone target |
| Diagnostics | located InvalidReact plus nonreportable/internal failure |

These are proposed review checks, not tests run for this bundle.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Gating.ts:12–49`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Gating.ts#L12-L49) · [`compiler/packages/babel-plugin-react-compiler/src/SSA/EnterSSA.ts:130–179`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/SSA/EnterSSA.ts#L130-L179) · [`compiler/packages/babel-plugin-react-compiler/src/Inference/InferReferenceEffects.ts:57–98`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Inference/InferReferenceEffects.ts#L57-L98) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/FlattenScopesWithHooksOrUse.ts:24–72`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/FlattenScopesWithHooksOrUse.ts#L24-L72) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts:13–53`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts#L13-L53) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:586–624`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L586-L624) · [`packages/react-reconciler/src/ReactFiberHooks.js:1119–1200`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/packages/react-reconciler/src/ReactFiberHooks.js#L1119-L1200) · [`compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts:116–163`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts#L116-L163)

## Coverage model

**Observed**

The complete git diff inventory is retained, including paths beyond the GitHub API 3,000-file cap. Every changed file receives a substantive/supporting/omitted coverage entry. Directly read anchors support the narrative; fixture/snapshot files support navigation and tests rather than pretending to be production code. Ancillary source and the Rust WIP receive explicit limited-review reasons.

Sources: [`compiler/docs/DEVELOPMENT_GUIDE.md:5–28`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/docs/DEVELOPMENT_GUIDE.md#L5-L28) · [`compiler/packages/snap/src/runner.ts:71–113`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/runner.ts#L71-L113)

## Rust and broader confidence

**Observed**

The development guide calls Rust WIP/unused. The N-API parser returns program/diagnostics through its own semantic-analysis path. Separate Rust snapshots and crates do not establish integration with the Babel compiler or parity. Compiler build, fixture suites, Rust tests and application compatibility tests were not executed here. The generated artifacts are review aids, not proof of correctness or approval readiness.

Sources: [`compiler/docs/DEVELOPMENT_GUIDE.md:5–28`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/docs/DEVELOPMENT_GUIDE.md#L5-L28) · [`compiler/crates/react_napi/src/lib.rs:82–121`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/crates/react_napi/src/lib.rs#L82-L121)

## Reconstructed tradeoff: conservative recomputation

**Inferred**

Reconstructed from the source and goals: preferring a safe dependency prefix and flattening hook-containing scopes favors valid React/JavaScript behavior over maximum cache reuse. The original authors historical decision process is unknown; no ADR is cited. A future optimization should preserve these invariants and measure startup/code-size impact as well as recomputation.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts:13–53`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts#L13-L53) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/FlattenScopesWithHooksOrUse.ts:24–72`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/FlattenScopesWithHooksOrUse.ts#L24-L72) · [`compiler/docs/DESIGN_GOALS.md:5–55`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/docs/DESIGN_GOALS.md#L5-L55)

## Fixture evidence flow

Which checks compare text and which compare executed behavior?

```mermaid
flowchart TD
 Fixture["Fixture + pragmas"] --> Worker["snap worker"]
 Worker --> Compile["Compiler transform"]
 Compile --> Golden["Golden generated output / expected error"]
 Compile --> Optional["Evaluator code when available"]
 Optional --> Sprout["Run original and compiled"]
 Sprout --> Compare["Compare kind / value / logs"]
 Props["Sequential props"] --> Sprout
```

Sources: [`compiler/packages/snap/src/runner.ts:71–113`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/runner.ts#L71-L113) · [`compiler/packages/snap/src/compiler.ts:32–66`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/compiler.ts#L32-L66) · [`compiler/packages/snap/src/runner-worker.ts:130–180`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/runner-worker.ts#L130-L180) · [`compiler/packages/snap/src/sprout/index.ts:31–63`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/sprout/index.ts#L31-L63) · [`compiler/packages/snap/src/sprout/evaluator.ts:114–142`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/sprout/evaluator.ts#L114-L142)

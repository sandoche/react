<!-- code-unpacked:reverse-design -->
## Code Unpacked · reverse-design

React Compiler — reconstructed architecture and review contracts

Source revision: `575477a2e8f9db57ef4a1bf0d3b449e4f8244af8`

The full inline explanation exceeds the comment budget. Complete documents, diagrams, and source coverage are preserved in the HTML attachment (extract the ZIP first when supplied).

<details><summary>Source coverage limitations</summary>

- compiler/apps/playground/public/favicon.ico: Binary source
- compiler/apps/playground/public/fonts/Source-Code-Pro-Regular.woff2: Binary source
- compiler/apps/playground/public/graphvizlib.wasm: Source exceeds 512 KB
- compiler/apps/playground/public/icon-180x180.png: Binary source
- compiler/crates/react_napi/yarn.lock: Lockfile metadata only
- compiler/yarn.lock: Lockfile metadata only
- PR metadata is a recorded snapshot; this run does not assert that it remains the latest PR revision.
- compiler/crates/react_hermes_parser/tests/fixtures/infer-types-through-type-cast.flow.js: parser diagnostics; structure omitted
- compiler/crates/react_hermes_parser/tests/fixtures/type-cast-expression.flow.js: parser diagnostics; structure omitted
- compiler/packages/babel-plugin-react-compiler/src/__tests__/fixtures/compiler/component-declaration-basic.flow.js: parser diagnostics; structure omitted
- compiler/packages/babel-plugin-react-compiler/src/__tests__/fixtures/compiler/destructuring-with-typecast-as-default-value.flow.js: parser diagnostics; structure omitted
- compiler/packages/babel-plugin-react-compiler/src/__tests__/fixtures/compiler/error.component-syntax-ref-gating.flow.js: parser diagnostics; structure omitted
- compiler/packages/babel-plugin-react-compiler/src/__tests__/fixtures/compiler/gating-with-hoisted-type-reference.flow.js: parser diagnostics; structure omitted
- compiler/packages/babel-plugin-react-compiler/src/__tests__/fixtures/compiler/hook-declaration-basic.flow.js: parser diagnostics; structure omitted
- compiler/packages/babel-plugin-react-compiler/src/__tests__/fixtures/compiler/infer-types-through-type-cast.flow.js: parser diagnostics; structure omitted
- compiler/packages/babel-plugin-react-compiler/src/__tests__/fixtures/compiler/type-annotations/type-annotation-as-array_.flow.js: parser diagnostics; structure omitted
- compiler/packages/babel-plugin-react-compiler/src/__tests__/fixtures/compiler/type-annotations/type-annotation-as-number_.flow.js: parser diagnostics; structure omitted
- compiler/packages/babel-plugin-react-compiler/src/__tests__/fixtures/compiler/type-cast-expression.flow.js: parser diagnostics; structure omitted
- packages/react/src/ReactHooks.js: parser diagnostics; structure omitted
- packages/react-reconciler/src/ReactFiberHooks.js: parser diagnostics; structure omitted
- Artifact-only repair: two Git C-quoted Unicode fixture paths were decoded to exact git paths and hydrated directly from the same pinned head. No PR/source recollection or shared-tooling edits were performed.
- Artifact-only correction required for two Unicode fixture paths: exact names and bytes recovered from the same pinned head; stable collector left C-quoted octals and omitted their content. Full path-set equality was checked separately.

22 of 22 source limitations shown. The complete list is retained in the artifact manifest and HTML.

</details>

### Download and open

[Download the complete reverse-design viewer (ZIP)](https://github.com/sandoche/react/raw/4c2bbc612a301bebd20c760a7486beefd8315ac2/code-unpacked-artifacts/reverse-design.html.zip). Extract it and open `index.html`; it works offline.

[Browse the committed artifact index](https://github.com/sandoche/react/tree/4c2bbc612a301bebd20c760a7486beefd8315ac2/code-unpacked-artifacts).

Delivery uses committed files in this fork; these links are not browser-uploaded attachments.

# Eligibility, gating and failure behavior

Document family: API contracts

## Reconstructed source contract

**Observed**

The observed plugin inputs include compilationMode, environment, gating, panicThreshold, noEmit, runtimeModule, source selection and suppression configuration. This document reconstructs behavior from source; it is not a separately published versioned API guarantee. Defaults include infer, panic none and noEmit false. Function opt-outs override modes; annotation mode otherwise requires opt-in. Program also rejects an absent filename when sources requires it and skips existing selected-runtime c imports.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Options.ts:34–113`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Options.ts#L34-L113) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Options.ts:177–207`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Options.ts#L177-L207) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:464–525`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L464-L525) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:216–269`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L216-L269)

## Gating changes binding form

**Observed**

Gating creates a conditional expression calling the configured external function and selecting compiled/original function expressions. A normal named declaration becomes const; default exports and other forms follow a different replacement form. Program checks top-level references before declaration when gating is enabled. Review hoisting as part of rollout correctness, not only feature-flag coverage.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Gating.ts:12–49`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Gating.ts#L12-L49) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:782–846`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L782-L846)

## Errors are part of the interface

**Observed**

Program logs known CompilerError details or PipelineError for unexpected failures. all_errors throws every error; critical_errors throws critical/unrecognized errors; invalid configuration always throws. A failed function is not queued for replacement. noEmit still performs compilation/analysis and success logging but prevents queued replacement. Critical-state handling and suppression checks deserve file-level cases, not just single-function tests.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:94–129`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L94-L129) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:300–341`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L300-L341) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:216–269`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L216-L269)

## Extension examples

**Proposed**

Proposed checks for a new mode or gating strategy: named and anonymous declarations; expression/default exports; top-level use before definition; existing c imports; a successful function followed by a failing one; noEmit with logger events; invalid config under panic none. Keep consumer options explicit because ESLint and healthcheck intentionally choose different panic thresholds.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Gating.ts:12–49`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Gating.ts#L12-L49) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:782–846`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L782-L846) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:300–341`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L300-L341) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:94–129`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L94-L129) · [`compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts:36–56`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/eslint-plugin-react-compiler/src/rules/ReactCompilerRule.ts#L36-L56) · [`compiler/packages/react-compiler-healthcheck/src/checks/reactCompiler.ts:19–65`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/react-compiler-healthcheck/src/checks/reactCompiler.ts#L19-L65)

## Gated replacement

Why does a rollout flag require a hoisting check?

```mermaid
flowchart TD
 Candidate["Compiled candidates"] --> Check["Check top-level pre-declaration uses"]
 Check -->|"error"| Error["Handle error / no replacement from this path"]
 Check -->|"allowed"| Gate["gate() ? compiled : original"]
 Gate --> Named["Named declaration: const binding"]
 Gate --> Other["Other forms: conditional expression"]
```

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Gating.ts:12–49`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Gating.ts#L12-L49) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:782–846`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L782-L846) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:94–129`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L94-L129)

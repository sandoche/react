# Inference and React-rule safety contracts

Document family: Requirements / PRD

## Observed assumptions, not universal JavaScript facts

**Observed**

Reference effects assume React function inputs, hook arguments/returns and values passed to JSX obey React immutability/ownership rules. Readonly is a use-level effect and permits later mutation. Type inference uses equations and the default config does not trust annotations. New library knowledge must respect these assumptions; simply recognizing a name as pure is not enough when aliases or closure capture remain.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Inference/InferReferenceEffects.ts:57–98`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Inference/InferReferenceEffects.ts#L57-L98) · [`compiler/packages/babel-plugin-react-compiler/src/TypeInference/InferTypes.ts:53–83`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/TypeInference/InferTypes.ts#L53-L83) · [`compiler/packages/babel-plugin-react-compiler/src/HIR/Environment.ts:151–226`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/HIR/Environment.ts#L151-L226)

## Alias and lifetime convergence

**Observed**

Mutable-range inference computes aliases, includes try/catch aliases, refines mutable ranges and store/phi alias information until canonical maps stabilize, then reinfers lifetimes/ranges. Scope inference groups co-mutating operands, not arbitrary syntax blocks. A mutation through an alias can therefore affect where a different value is memoized.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Inference/InferMutableRanges.ts:16–55`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Inference/InferMutableRanges.ts#L16-L55) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/InferReactiveScopeVariables.ts:28–71`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/InferReactiveScopeVariables.ts#L28-L71) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/InferReactiveScopeVariables.ts:84–125`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/InferReactiveScopeVariables.ts#L84-L125)

## Input rules and output invariants

**Observed**

Hook validation forbids conditional calls for known/potential hooks and first-class use of known hooks. Output safety separately flattens scopes transitively containing hooks/use. Default flags enable hook and unconditional setState checks, but ref/effect/capitalized-call validations differ. Preserved manual memoization runs late because pruning may change whether a value stays memoized.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Validation/ValidateHooksUsage.ts:79–129`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Validation/ValidateHooksUsage.ts#L79-L129) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/FlattenScopesWithHooksOrUse.ts:24–72`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/FlattenScopesWithHooksOrUse.ts#L24-L72) · [`compiler/packages/babel-plugin-react-compiler/src/HIR/Environment.ts:151–226`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/HIR/Environment.ts#L151-L226) · [`compiler/packages/babel-plugin-react-compiler/src/Validation/ValidatePreservedManualMemoization.ts:34–49`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Validation/ValidatePreservedManualMemoization.ts#L34-L49) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:425–437`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L425-L437)

## Known limit

**Observed**

The setState validator documents a false negative where a setter is stored in an array and later extracted/called. This prevents a clean diagnostic result from being interpreted as full Rules-of-React proof. Broader custom-hook/library behavior and dynamic calls remain review gaps unless modeled and exercised.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Validation/ValidateNoSetStateInRender.ts:14–44`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Validation/ValidateNoSetStateInRender.ts#L14-L44) · [`compiler/packages/babel-plugin-react-compiler/src/Inference/InferReferenceEffects.ts:57–98`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Inference/InferReferenceEffects.ts#L57-L98)

# Generated cache protocol and runtime compatibility

Document family: API contracts

## Emitted protocol

**Observed**

Codegen assigns input slots and emits !== comparisons, ORing them for invalidation. It assigns output slots for declarations/reassignments and restores them on cache hits. A scope with no dependencies tests the first output for the memo-cache sentinel. Computation occurs before appended cache stores; the generated branch is part of the protocol expected by React. Early-return values use a separate sentinel check.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:453–500`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L453-L500) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:502–549`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L502-L549) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:586–624`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L586-L624) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:676–701`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L676-L701)

## Native React boundary

**Observed**

Default import source is react/compiler-runtime. Its c export delegates via ReactHooks into the current dispatcher. The reconciler locates or allocates data, initializes sentinel entries and increments a cache index. Existing data with a different requested size triggers a development diagnostic. The reconciler explicitly discusses clone/share behavior and interrupted render reuse relying on compiler writes. These files are unchanged contextual evidence, not changes introduced by this PR.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:216–269`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L216-L269) · [`packages/react/compiler-runtime.js:1–10`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/packages/react/compiler-runtime.js#L1-L10) · [`packages/react/src/ReactHooks.js:190–194`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/packages/react/src/ReactHooks.js#L190-L194) · [`packages/react-reconciler/src/ReactFiberHooks.js:1119–1200`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/packages/react-reconciler/src/ReactFiberHooks.js#L1119-L1200)

## Standalone compatibility surface

**Observed**

The new standalone package c uses useState to initialize an array with the same Symbol.for sentinel. It includes $read/$reset and optional dispatcher guards using private internals. $makeReadOnly is an explicit TODO throw. Its peer range lists React 18.2/19, but neither metadata nor source alone establishes all concurrent-render semantics or supported combinations. runtimeModule is the compiler seam for a different import source.

Sources: [`compiler/packages/react-compiler-runtime/src/index.ts:8–45`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/react-compiler-runtime/src/index.ts#L8-L45) · [`compiler/packages/react-compiler-runtime/src/index.ts:191–199`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/react-compiler-runtime/src/index.ts#L191-L199) · [`compiler/packages/react-compiler-runtime/src/index.ts:106–189`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/react-compiler-runtime/src/index.ts#L106-L189) · [`compiler/packages/react-compiler-runtime/package.json:1–17`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/react-compiler-runtime/package.json#L1-L17) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Options.ts:34–113`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Options.ts#L34-L113)

## Proposed compatibility matrix

**Proposed**

For a runtime change, verify cold render, stable-input hit, changed input, multiple compiled hooks, constant slot count, early return, error/suspense interruption, update retry and development source reset. Test the real selected runtime with emitted code. Compare native and standalone behavior deliberately; do not equate a shared sentinel string with full behavioral parity.

Sources: [`packages/react-reconciler/src/ReactFiberHooks.js:1119–1200`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/packages/react-reconciler/src/ReactFiberHooks.js#L1119-L1200) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:72–133`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L72-L133) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:676–701`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L676-L701) · [`compiler/packages/react-compiler-runtime/src/index.ts:8–45`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/react-compiler-runtime/src/index.ts#L8-L45)

## Runtime cache use

What happens on a render with a cache hit or changed input?

```mermaid
sequenceDiagram
 participant F as Compiled function
 participant C as Selected c runtime
 participant A as Cache array
 F->>C: c(fixed slot count)
 C-->>F: cache array
 F->>A: compare dependency slots
 alt input changed or cold sentinel
 F->>F: compute scope
 F->>A: store dependencies and outputs
 else inputs unchanged
 A-->>F: load outputs
 end
```

Sources: [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:72–133`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L72-L133) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:453–500`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L453-L500) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:502–549`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L502-L549) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:586–624`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L586-L624) · [`compiler/packages/react-compiler-runtime/src/index.ts:8–45`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/react-compiler-runtime/src/index.ts#L8-L45)

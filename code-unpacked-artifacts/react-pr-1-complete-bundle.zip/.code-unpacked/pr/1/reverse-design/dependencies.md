# Dependency safety and invalidation design

Document family: Data flow

## Inputs to a scope

**Observed**

propagateScopeDependencies includes non-stable values created before a scope and propagates nested dependencies upward. It also tracks temporaries used outside their defining scope. Scope membership, escaping outputs and dependencies must agree, or emitted cache reuse can leave a required value unavailable.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/PropagateScopeDependencies.ts:42–74`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/PropagateScopeDependencies.ts#L42-L74) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:502–549`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L502-L549)

## A dependency comparison can introduce behavior

**Observed**

Final dependencies must all be safe to access unconditionally. A property chain used behind a guard cannot automatically be read before the guard. DeriveMinimalDependencies can use an unconditionally accessed prefix, relying on deep immutability to make it conservative: unchanged parent implies unchanged child, while changed parent may cause harmless extra recomputation. This is a correctness/cost tradeoff, not perfect dependency minimality.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts:13–53`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts#L13-L53) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts:127–149`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts#L127-L149) · [`compiler/docs/DESIGN_GOALS.md:5–55`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/docs/DESIGN_GOALS.md#L5-L55)

## Conditional control flow matters

**Proposed**

The propagation pass describes poisoned scope state for nested jump targets and outermost throws/returns, causing dependencies to be treated as conditional. Proposed review cases include optional paths, null checks, a break/continue into an enclosing target and a return before a scope starts. Check both error behavior and values across repeated renders.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/PropagateScopeDependencies.ts:143–156`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/PropagateScopeDependencies.ts#L143-L156) · [`compiler/packages/snap/src/sprout/evaluator.ts:114–142`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/sprout/evaluator.ts#L114-L142) · [`compiler/packages/snap/src/sprout/index.ts:31–63`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/sprout/index.ts#L31-L63)

## Where to extend

**Proposed**

For finer-grained invalidation, inspect property dependency derivation and conditional access classification before changing comparison codegen. Keep safe access as a hard invariant and measure extra invalidation separately. Add focused input/snapshot pairs and evaluator sequences before accepting a smaller slot count as an improvement.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts:13–53`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts#L13-L53) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts:127–149`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts#L127-L149) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:453–500`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L453-L500) · [`compiler/docs/DEVELOPMENT_GUIDE.md:5–28`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/docs/DEVELOPMENT_GUIDE.md#L5-L28)

## Guarded path to safe comparison

Why may a dependency use a broader parent path?

```mermaid
flowchart TD
 Read["Deep property read inside a guard"] --> Analyze["Classify conditional access"]
 Analyze --> Safe["Choose safe unconditional dependency prefix"]
 Safe --> Compare["Emit cache comparison"]
 Compare --> Changed["Changed: recompute and store"]
 Compare --> Same["Same: load cached outputs"]
```

Sources: [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts:13–53`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts#L13-L53) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts:127–149`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts#L127-L149) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:453–500`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L453-L500) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts:586–624`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/CodegenReactiveFunction.ts#L586-L624)

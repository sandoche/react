# Pass contracts and control-flow transformations

Document family: Sequence diagrams

## The actual pass order

**Observed**

Pipeline.ts is the execution authority. It lowers to HIR, prunes maybe-throws, validates context lvalues/useMemo, drops manual memoization, inlines IIFEs, normalizes blocks, asserts identities/successors, enters SSA, removes redundant phis and propagates constants. Type inference and configured hook/capitalized-call validation precede function/effect analysis. Effects precede DCE because dead code may affect inference. Mutable ranges precede configured ref/setState validation and reactive-place inference.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:140–195`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L140-L195) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:191–223`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L191-L223)

## Two IR boundaries

**Observed**

HIR stores high-level constructs in a control-flow graph, supporting precise evaluation order and explicit joins. SSA records definitions and phis across predecessors. After scope work the compiler builds a ReactiveFunction hybrid of HIR and AST, then emits Babel AST. This is why new syntax needs consistent lowering, visitors and printing, while a final text rewrite bypasses analysis invariants.

Sources: [`compiler/docs/DESIGN_GOALS.md:5–55`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/docs/DESIGN_GOALS.md#L5-L55) · [`compiler/packages/babel-plugin-react-compiler/src/SSA/EnterSSA.ts:130–179`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/SSA/EnterSSA.ts#L130-L179) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:246–284`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L246-L284) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:425–437`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L425-L437)

## Scope-path feature flag

**Observed**

enableReactiveScopesInHIR defaults true. The pipeline has an HIR scope-terminal/alignment/merge path and a conditional older ReactiveFunction alignment/merge/build-block path. Both converge before later flattening, dependency propagation and pruning. An extension must name which path it changes and exercise both configurations when both remain supported.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/HIR/Environment.ts:151–226`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/HIR/Environment.ts#L151-L226) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:246–284`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L246-L284) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:318–380`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L318-L380)

## Pass insertion checklist

**Proposed**

Proposed review questions: Which identifiers and block ordering does the pass require? Does it change lvalues, aliases, effect classifications, mutable ranges, scope membership or terminal targets? Which assertions still run afterward? Add a minimal regression fixture at the first incorrect intermediate stage and behavioral comparison at the output boundary.

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:140–195`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L140-L195) · [`compiler/packages/babel-plugin-react-compiler/src/Inference/InferMutableRanges.ts:16–55`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Inference/InferMutableRanges.ts#L16-L55) · [`compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/InferReactiveScopeVariables.ts:28–71`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/InferReactiveScopeVariables.ts#L28-L71) · [`compiler/packages/snap/src/sprout/index.ts:31–63`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/snap/src/sprout/index.ts#L31-L63)

## From HIR to cache AST

In what order do representation and safety boundaries occur?

```mermaid
flowchart LR
 AST["Selected Babel function"] --> HIR["HIR / CFG"]
 HIR --> SSA["SSA / constants / types"]
 SSA --> Effects["Effects and aliases"]
 Effects --> Ranges["Mutable ranges / validation"]
 Ranges --> Scopes["Reactive scopes"]
 Scopes --> Reactive["ReactiveFunction"]
 Reactive --> Safety["Flatten hooks / safe dependencies"]
 Safety --> Prune["Prune / merge / preserve checks"]
 Prune --> Emit["Memoized Babel AST"]
```

Sources: [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:140–195`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L140-L195) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:191–223`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L191-L223) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:246–284`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L246-L284) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:318–380`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L318-L380) · [`compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts:425–437`](https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Pipeline.ts#L425-L437)

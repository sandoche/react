# React Compiler: three review traps

Original black-and-white stick-figure comics about three distinct compiler invariants, with complete in-image dialogue and captions.

Source revision: 575477a2e8f9db57ef4a1bf0d3b449e4f8244af8

## The flag moved the floor

### Panel 1

Scene: compileProgram stick figure points at a stage labeled function declaration. A small arrow labeled call before declaration reaches the stage.

compileProgram: This call relies on hoisting.

Before gating: a declaration.

Evidence: compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:782-846 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L782-L846)

### Panel 2

Scene: Gating.ts stick figure replaces the stage with a platform labeled const and two doors labeled compiled and original.

Gating.ts: The flag picks a function. It does not lift the floor.

After gating: const plus a choice.

Evidence: compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Gating.ts:12-49 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Gating.ts#L12-L49)

### Panel 3

Scene: compileProgram stops a call arrow at a barrier before the const platform. The Gating figure holds a small checklist.

compileProgram: Check hoisting before rollout.

Review pre-declaration uses.

Evidence: compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts:782-846 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Program.ts#L782-L846); compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Gating.ts:12-49 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Entrypoint/Gating.ts#L12-L49)

Limitation: Metaphor for named-declaration gating. Default exports and function expressions have different replacement forms; this is not a complete treatment of JavaScript hoisting.

## The cache cannot skip roll call

### Panel 1

Scene: FlattenScopesWithHooksOrUse stick figure sees a box labeled memoized scope. Inside is a small bell labeled hook call.

FlattenScopesWithHooksOrUse: A cache hit would skip this whole box.

An attractive cache boundary.

Evidence: compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/FlattenScopesWithHooksOrUse.ts:24-72 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/FlattenScopesWithHooksOrUse.ts#L24-L72)

### Panel 2

Scene: The same figure opens and flattens the box. The hook bell remains on a straight path labeled render.

FlattenScopesWithHooksOrUse: The hook still has to participate.

Flatten scopes containing hooks.

Evidence: compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/FlattenScopesWithHooksOrUse.ts:24-72 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/FlattenScopesWithHooksOrUse.ts#L24-L72)

### Panel 3

Scene: The figure stands beside the straight render path, ringing the hook bell. An empty cache box sits to the side.

FlattenScopesWithHooksOrUse: Less memoization. Correct roll call.

Correctness costs a cache opportunity.

Evidence: compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/FlattenScopesWithHooksOrUse.ts:24-72 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/FlattenScopesWithHooksOrUse.ts#L24-L72); compiler/packages/babel-plugin-react-compiler/src/Validation/ValidateHooksUsage.ts:79-129 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/Validation/ValidateHooksUsage.ts#L79-L129)

Limitation: Hook/use scope flattening is output safety, not exhaustive input validation or a promise that every value is memoized.

## Do not wake the property

### Panel 1

Scene: DeriveMinimalDependencies stick figure peers through a gate labeled if user. Behind it sleeps a cat-shaped property labeled user.name.

DeriveMinimalDependencies: That read only happens after the guard.

A deep read lives behind a guard.

Evidence: compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts:13-53 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts#L13-L53)

### Panel 2

Scene: The figure stops a magnifying glass labeled cache comparison from reaching over the closed gate toward user.name.

DeriveMinimalDependencies: Checking the deep path here could throw.

Dependency checks run outside the guard.

Evidence: compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts:13-53 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts#L13-L53); compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts:127-149 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts#L127-L149)

### Panel 3

Scene: The figure checks a safe card labeled user outside the gate. The property remains undisturbed.

DeriveMinimalDependencies: A little extra recomputation beats a new crash.

Track a safe parent dependency.

Evidence: compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts:13-53 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/packages/babel-plugin-react-compiler/src/ReactiveScopes/DeriveMinimalDependencies.ts#L13-L53); compiler/docs/DESIGN_GOALS.md:5-55 (https://github.com/sandoche/react/blob/575477a2e8f9db57ef4a1bf0d3b449e4f8244af8/compiler/docs/DESIGN_GOALS.md#L5-L55)

Limitation: A broader dependency can cause extra recomputation. Safety relies on the compiler immutability assumptions and does not promise minimal invalidation.
